package tad.conjuntoDinamico;

import java.util.Arrays;

public class MeuConjuntoDinamico implements ConjuntoDinamicoIF<Integer> {

    private static final int TAMANHO_INICIAL = 10;
    private static final int TAXA_AUMENTO = 2;

    private Integer[] meusDados;
    private int posInsercao;

    public MeuConjuntoDinamico() {
        meusDados = new Integer[TAMANHO_INICIAL];
        posInsercao = 0;
    }

    @Override
    public void inserir(Integer item) {
        if (posInsercao >= meusDados.length) {
            meusDados = aumentarArray();
        }
        meusDados[posInsercao++] = item;
    }

    private Integer[] aumentarArray() {
        int novoTamanho = meusDados.length * TAXA_AUMENTO;
        Integer[] novoArray = new Integer[novoTamanho];
        System.arraycopy(meusDados, 0, novoArray, 0, meusDados.length);
        return novoArray;
    }

    @Override
    public Integer remover(Integer item) {
        int index = buscarIndice(item);
        if (index != -1) {
            Integer valorRemovido = meusDados[index];
            System.arraycopy(meusDados, index + 1, meusDados, index, posInsercao - index - 1);
            meusDados[--posInsercao] = null;
            return valorRemovido;
        }
        return null;
    }

    private int buscarIndice(Integer item) {
        for (int i = 0; i < posInsercao; i++) {
            if (item.equals(meusDados[i])) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public Integer predecessor(Integer item) {
        Integer predecessor = null;
        for (int i = 0; i < posInsercao; i++) {
            if (meusDados[i].compareTo(item) < 0 && (predecessor == null || meusDados[i].compareTo(predecessor) > 0)) {
                predecessor = meusDados[i];
            }
        }
        return predecessor;
    }

    @Override
    public Integer sucessor(Integer item) {
        Integer sucessor = null;
        for (int i = 0; i < posInsercao; i++) {
            if (meusDados[i].compareTo(item) > 0 && (sucessor == null || meusDados[i].compareTo(sucessor) < 0)) {
                sucessor = meusDados[i];
            }
        }
        return sucessor;
    }

    @Override
    public int tamanho() {
        return posInsercao;
    }

    @Override
    public Integer buscar(Integer item) {
        for (int i = 0; i < posInsercao; i++) {
            if (item.equals(meusDados[i])) {
                return meusDados[i];
            }
        }
        return null;
    }

    @Override
    public Integer minimum() {
        if (posInsercao == 0) {
            return null;
        }
        Integer minimum = meusDados[0];
        for (int i = 1; i < posInsercao; i++) {
            if (meusDados[i].compareTo(minimum) < 0) {
                minimum = meusDados[i];
            }
        }
        return minimum;
    }

    @Override
    public Integer maximum() {
        if (posInsercao == 0) {
            return null;
        }
        Integer maximum = meusDados[0];
        for (int i = 1; i < posInsercao; i++) {
            if (meusDados[i].compareTo(maximum) > 0) {
                maximum = meusDados[i];
            }
        }
        return maximum;
    }

    @Override
    public String toString() {
        return Arrays.toString(Arrays.copyOf(meusDados, posInsercao));
    }
}
