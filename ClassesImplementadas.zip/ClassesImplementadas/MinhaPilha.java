package tad.pilha;

public class MinhaPilha implements PilhaIF<Integer> {

    private int tamanho;
    private Integer[] meusDados;
    private int topo;

    public MinhaPilha(int tamanho) {
        this.tamanho = tamanho;
        this.meusDados = new Integer[tamanho];
        this.topo = -1;
    }

    public MinhaPilha() {
        this(10); // Tamanho padrão da pilha é 10
    }

    @Override
    public void empilhar(Integer item) {
        if (topo == tamanho - 1) {
            throw new IllegalStateException("A pilha está cheia");
        }
        topo++;
        meusDados[topo] = item;
    }

    @Override
    public Integer desempilhar() {
        if (isEmpty()) {
            throw new IllegalStateException("A pilha está vazia");
        }
        Integer item = meusDados[topo];
        meusDados[topo] = null;
        topo--;
        return item;
    }

    @Override
    public Integer topo() {
        if (isEmpty()) {
            throw new IllegalStateException("A pilha está vazia");
        }
        return meusDados[topo];
    }

    @Override
    public PilhaIF<Integer> multitop(int k) {
        if (k <= 0 || k > tamanho) {
            throw new IllegalArgumentException("O valor de k deve ser positivo e menor ou igual ao tamanho da pilha");
        }

        PilhaIF<Integer> subPilha = new MinhaPilha(k);
        for (int i = topo; i > topo - k; i--) {
            try {
				subPilha.empilhar(meusDados[i]);
			} catch (PilhaCheiaException e) {
				e.printStackTrace();
			}
        }
        return subPilha;
    }

    @Override
    public boolean isEmpty() {
        return topo == -1;
    }
}
